/**
 * detection.js
 *
 * RAW -> DETECTED HLS controller for Raspberry Pi / Mac.
 *
 * Important:
 * - RAW stream remains visible while YOLO starts.
 * - DETECTED stream is used only after multiple fresh TS segments exist.
 * - Only one HLS.js instance is allowed per camera.
 * - Old HLS/MSE state is completely destroyed before source switching.
 * - Direct hls_detected URL is used for detected playback.
 * - No smart-route is used during RAW -> DETECTED switching.
 */

const hlsInstances = {};
const switchGeneration = {};
const retryTimers = {};
const detectionWaiters = {};


/* ============================================================
   LOGGING
   ============================================================ */

function log(idx, ...args) {
    console.log(`[HLS camera ${idx}]`, ...args);
}

function warn(idx, ...args) {
    console.warn(`[HLS camera ${idx}]`, ...args);
}

function errorLog(idx, ...args) {
    console.error(`[HLS camera ${idx}]`, ...args);
}


/* ============================================================
   HELPERS
   ============================================================ */

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


function stopSimulatedCanvas(idx, video) {
    if (video && video.srcObject) {
        video.srcObject = null;
    }
}


/**
 * Completely destroy the HLS instance for a camera.
 */
function destroyHls(idx) {
    if (retryTimers[idx]) {
        clearTimeout(retryTimers[idx]);
        delete retryTimers[idx];
    }

    const hls = hlsInstances[idx];

    if (hls) {
        log(idx, "Destroying HLS instance");

        try {
            hls.stopLoad();
        } catch (_) {}

        try {
            hls.detachMedia();
        } catch (_) {}

        try {
            hls.destroy();
        } catch (_) {}

        delete hlsInstances[idx];
    }
}


/**
 * Hard reset video/MSE state.
 *
 * This is important when switching:
 *
 * RAW -> DETECTED
 * DETECTED -> RAW
 */
function resetVideo(video) {
    if (!video) return;

    try {
        video.pause();
    } catch (_) {}

    try {
        video.removeAttribute("src");
    } catch (_) {}

    try {
        video.srcObject = null;
    } catch (_) {}

    try {
        video.load();
    } catch (_) {}
}


/**
 * Increment generation so an old async operation cannot
 * switch the player after a newer operation has started.
 */
function newGeneration(idx) {
    switchGeneration[idx] = (switchGeneration[idx] || 0) + 1;
    return switchGeneration[idx];
}


/* ============================================================
   HLS PLAYER
   ============================================================ */

/**
 * Start HLS playback.
 *
 * Only one HLS instance can exist for a camera.
 */
function playHLS(video, url, idx, options = {}) {

    const generation = options.generation || switchGeneration[idx] || 0;
    const label = options.label || "HLS";

    if (!video || !url) {
        errorLog(idx, "playHLS called without video/url");
        return;
    }

    log(idx, `Starting ${label}:`, url);

    /*
     * Destroy previous player first.
     */
    destroyHls(idx);

    /*
     * Flush MediaSource/video state.
     */
    resetVideo(video);

    /*
     * Cache bust only playlist.
     */
    const separator = url.includes("?") ? "&" : "?";
    const fullUrl = `${url}${separator}t=${Date.now()}`;

    /*
     * Safari/native HLS.
     */
    if (typeof Hls === "undefined" || !Hls.isSupported()) {

        log(idx, `${label}: using native HLS`);

        video.src = fullUrl;
        video.load();

        video.play().catch(err => {
            warn(idx, `${label}: autoplay failed`, err);
        });

        return;
    }


    /*
     * HLS.js configuration.
     */
    const hls = new Hls({

        enableWorker: true,

        /*
         * Live security camera stream.
         */
        lowLatencyMode: true,

        /*
         * Stay close to live edge.
         */
        liveSyncDurationCount: 2,

        /*
         * Do not retain old media.
         */
        liveBackBufferLength: 0,
        backBufferLength: 0,

        /*
         * Keep enough data to survive small RPi delays.
         */
        maxBufferLength: 8,
        maxMaxBufferLength: 12,

        /*
         * Manifest.
         */
        manifestLoadingTimeOut: 20000,
        manifestLoadingMaxRetry: 10,
        manifestLoadingRetryDelay: 1000,

        /*
         * Level/playlist.
         */
        levelLoadingTimeOut: 20000,
        levelLoadingMaxRetry: 10,

        /*
         * TS fragments.
         */
        fragLoadingTimeOut: 20000,
        fragLoadingMaxRetry: 10,

        /*
         * Start at live edge.
         */
        startPosition: -1
    });


    hlsInstances[idx] = hls;


    /* ========================================================
       HLS EVENTS
       ======================================================== */

    hls.on(Hls.Events.MEDIA_ATTACHED, () => {
        log(idx, `${label}: MEDIA_ATTACHED`);

        /*
         * Only load if this is still the current player.
         */
        if (
            hlsInstances[idx] !== hls ||
            switchGeneration[idx] !== generation
        ) {
            warn(idx, `${label}: stale HLS instance ignored`);
            return;
        }

        hls.loadSource(fullUrl);
    });


    hls.on(Hls.Events.MANIFEST_LOADING, (_, data) => {
        log(idx, `${label}: MANIFEST_LOADING`, data?.url);
    });


    hls.on(Hls.Events.MANIFEST_LOADED, (_, data) => {
        log(idx, `${label}: MANIFEST_LOADED`);
    });


    hls.on(Hls.Events.MANIFEST_PARSED, (_, data) => {

        log(
            idx,
            `${label}: MANIFEST_PARSED`,
            `levels=${data?.levels?.length || 0}`
        );

        stopSimulatedCanvas(idx, video);

        video.muted = true;

        video.play().catch(err => {
            warn(idx, `${label}: autoplay failed`, err);
        });
    });


    hls.on(Hls.Events.LEVEL_LOADED, (_, data) => {

        const details = data?.details;

        if (!details) return;

        log(
            idx,
            `${label}: LEVEL_LOADED`,
            `startSN=${details.startSN}`,
            `endSN=${details.endSN}`,
            `live=${details.live}`,
            `segments=${details.fragments?.length || 0}`
        );
    });


    hls.on(Hls.Events.FRAG_LOADING, (_, data) => {

        if (data?.frag) {
            log(
                idx,
                `${label}: FRAG_LOADING`,
                `SN=${data.frag.sn}`,
                data.frag.relurl || data.frag.url || ""
            );
        }
    });


    hls.on(Hls.Events.FRAG_LOADED, (_, data) => {

        if (data?.frag) {
            log(
                idx,
                `${label}: FRAG_LOADED`,
                `SN=${data.frag.sn}`
            );
        }
    });


    hls.on(Hls.Events.FRAG_BUFFERED, (_, data) => {

        if (data?.frag) {
            log(
                idx,
                `${label}: FRAG_BUFFERED`,
                `SN=${data.frag.sn}`
            );
        }

        /*
         * Once an actual fragment is buffered,
         * ensure playback is running.
         */
        if (
            hlsInstances[idx] === hls &&
            switchGeneration[idx] === generation
        ) {
            video.play().catch(() => {});
        }
    });


    hls.on(Hls.Events.ERROR, (_, data) => {

        warn(
            idx,
            `${label}: HLS ERROR`,
            {
                type: data?.type,
                details: data?.details,
                fatal: data?.fatal,
                url: data?.url
            }
        );


        /*
         * Recover media errors.
         */
        if (
            data?.type === Hls.ErrorTypes.MEDIA_ERROR &&
            !data?.fatal
        ) {
            try {
                hls.recoverMediaError();
                log(idx, `${label}: recoverMediaError()`);
            } catch (_) {}

            return;
        }


        /*
         * Non-fatal error.
         *
         * Do not create another HLS player.
         */
        if (!data?.fatal) {
            return;
        }


        /*
         * Ignore stale player.
         */
        if (hlsInstances[idx] !== hls) {
            return;
        }


        errorLog(
            idx,
            `${label}: FATAL ERROR`,
            data?.type,
            data?.details
        );


        /*
         * Destroy this player.
         */
        destroyHls(idx);


        /*
         * Retry only if the generation is still current.
         */
        if (switchGeneration[idx] !== generation) {
            return;
        }


        if (retryTimers[idx]) {
            return;
        }


        retryTimers[idx] = setTimeout(() => {

            delete retryTimers[idx];

            if (switchGeneration[idx] !== generation) {
                return;
            }

            log(idx, `${label}: retrying`);

            playHLS(video, url, idx, {
                generation,
                label
            });

        }, 2000);
    });


    /*
     * IMPORTANT:
     *
     * Attach media first.
     * loadSource happens from MEDIA_ATTACHED.
     */
    hls.attachMedia(video);
}


/* ============================================================
   PLAYLIST INSPECTION
   ============================================================ */


/**
 * Read HLS playlist.
 */
async function getPlaylist(url) {

    const response = await fetch(
        `${url}?t=${Date.now()}`,
        {
            method: "GET",
            cache: "no-store"
        }
    );

    if (!response.ok) {
        throw new Error(`Playlist HTTP ${response.status}`);
    }

    const text = await response.text();

    const lines = text
        .split("\n")
        .map(line => line.trim())
        .filter(Boolean);


    const mediaSequenceLine = lines.find(
        line => line.startsWith("#EXT-X-MEDIA-SEQUENCE:")
    );


    const mediaSequence = mediaSequenceLine
        ? parseInt(
            mediaSequenceLine.split(":")[1],
            10
        )
        : null;


    const segments = lines.filter(
        line => line.endsWith(".ts")
    );


    return {
        text,
        mediaSequence,
        segments
    };
}


/**
 * Check whether a TS segment actually exists.
 *
 * HEAD is used so we do not download the complete TS file.
 */
async function checkSegment(url) {

    try {

        const response = await fetch(
            `${url}?t=${Date.now()}`,
            {
                method: "HEAD",
                cache: "no-store"
            }
        );


        if (!response.ok) {
            return {
                ok: false,
                status: response.status,
                size: 0
            };
        }


        const size = parseInt(
            response.headers.get("content-length") || "0",
            10
        );


        return {
            ok: true,
            status: response.status,
            size
        };

    } catch (err) {

        return {
            ok: false,
            status: 0,
            size: 0
        };
    }
}


/* ============================================================
   WAIT FOR DETECTED STREAM
   ============================================================ */


/**
 * Wait until detected HLS is genuinely ready.
 *
 * We intentionally do NOT switch after the first TS.
 *
 * Conditions:
 *
 * 1. Playlist exists.
 * 2. At least 3 segments exist.
 * 3. Media sequence exists.
 * 4. Playlist is stable.
 * 5. Latest segment exists.
 * 6. Playlist advances.
 */
async function waitAndSwitch(video, meta, idx, box) {

    const TIMEOUT_MS = 120000;

    const POLL_MS = 1000;

    const REQUIRED_SEGMENTS = 3;

    const detectedUrl = meta.hls_detected;

    if (!detectedUrl) {
        errorLog(idx, "No hls_detected URL");
        return;
    }


    const generation = newGeneration(idx);

    log(
        idx,
        "Waiting for detected stream",
        detectedUrl
    );


    const startedAt = Date.now();

    let previousMediaSequence = null;

    let stableCount = 0;

    let lastSegment = null;


    while (Date.now() - startedAt < TIMEOUT_MS) {

        /*
         * User clicked Stop.
         */
        if (!box.classList.contains("detecting")) {
            log(idx, "Detection stopped while waiting");
            return;
        }


        /*
         * Another operation started.
         */
        if (switchGeneration[idx] !== generation) {
            log(idx, "Generation changed; aborting waiter");
            return;
        }


        try {

            const playlist = await getPlaylist(
                detectedUrl
            );


            log(
                idx,
                "Detected playlist:",
                `mediaSequence=${playlist.mediaSequence}`,
                `segments=${playlist.segments.length}`,
                playlist.segments
            );


            /*
             * Need enough rolling segments.
             */
            if (
                playlist.segments.length <
                REQUIRED_SEGMENTS
            ) {

                log(
                    idx,
                    `Waiting for ${REQUIRED_SEGMENTS} segments`
                );

                await sleep(POLL_MS);
                continue;
            }


            /*
             * Check whether playlist is advancing.
             */
            if (
                previousMediaSequence !== null &&
                playlist.mediaSequence !== null
            ) {

                if (
                    playlist.mediaSequence >
                    previousMediaSequence
                ) {

                    stableCount++;

                    log(
                        idx,
                        "Detected playlist advanced",
                        `stableCount=${stableCount}`
                    );

                } else {

                    /*
                     * Same playlist is okay,
                     * but we want it to advance at least once.
                     */
                    log(
                        idx,
                        "Playlist has not advanced yet"
                    );
                }
            }


            previousMediaSequence =
                playlist.mediaSequence;


            /*
             * Get latest segment.
             */
            const newestSegment =
                playlist.segments[
                    playlist.segments.length - 1
                ];


            /*
             * Build absolute TS URL.
             */
            const base =
                detectedUrl.replace(
                    /\/[^/]+$/,
                    "/"
                );


            const segmentUrl =
                base + newestSegment;


            /*
             * Avoid checking the same segment repeatedly
             * unless playlist advances.
             */
            if (
                newestSegment !== lastSegment ||
                stableCount === 0
            ) {

                log(
                    idx,
                    "Checking detected TS:",
                    newestSegment
                );


                const check =
                    await checkSegment(
                        segmentUrl
                    );


                log(
                    idx,
                    "TS check:",
                    newestSegment,
                    `HTTP=${check.status}`,
                    `size=${check.size}`
                );


                if (
                    check.ok &&
                    check.size > 1000
                ) {

                    /*
                     * Require the playlist to have
                     * advanced or already have a healthy
                     * number of segments.
                     */
                    if (
                        stableCount >= 1 ||
                        playlist.segments.length >= 4
                    ) {

                        /*
                         * Final safety checks.
                         */
                        if (
                            !box.classList.contains(
                                "detecting"
                            )
                        ) {
                            return;
                        }


                        if (
                            switchGeneration[idx] !==
                            generation
                        ) {
                            return;
                        }


                        log(
                            idx,
                            "Detected HLS READY",
                            `segment=${newestSegment}`,
                            `mediaSequence=${playlist.mediaSequence}`
                        );


                        /*
                         * Remove loading overlay.
                         */
                        removeAiLoadingOverlay(box);


                        /*
                         * IMPORTANT:
                         *
                         * Only NOW destroy RAW player.
                         */
                        log(
                            idx,
                            "Switching RAW -> DETECTED"
                        );


                        /*
                         * Destroy current RAW player.
                         */
                        destroyHls(idx);


                        /*
                         * Reset MSE/video.
                         */
                        resetVideo(video);


                        /*
                         * Small delay allows MediaSource
                         * cleanup before attaching detected HLS.
                         */
                        await sleep(150);


                        /*
                         * Make sure user did not stop
                         * during the delay.
                         */
                        if (
                            !box.classList.contains(
                                "detecting"
                            )
                        ) {
                            return;
                        }


                        if (
                            switchGeneration[idx] !==
                            generation
                        ) {
                            return;
                        }


                        /*
                         * Start detected stream.
                         */
                        playHLS(
                            video,
                            detectedUrl,
                            idx,
                            {
                                generation,
                                label: "DETECTED"
                            }
                        );


                        return;
                    }
                }
            }


            lastSegment = newestSegment;

        } catch (err) {

            warn(
                idx,
                "Detected playlist check failed:",
                err
            );
        }


        await sleep(POLL_MS);
    }


    /*
     * Timeout.
     */
    if (!box.classList.contains("detecting")) {
        return;
    }


    warn(
        idx,
        "Detected HLS timeout after 120 seconds"
    );


    const badge =
        box.querySelector(".mode-badge");


    if (badge) {

        badge.className =
            "mode-badge raw";

        badge.textContent =
            "⚠ AI timeout — retrying...";
    }


    /*
     * Restart detection after 5 seconds.
     */
    setTimeout(async () => {

        if (
            !box.classList.contains("detecting")
        ) {
            return;
        }


        try {

            const cm =
                await (
                    await fetch(
                        "/api/camera-models"
                    )
                ).json();


            const camStr = String(idx);

            const models =
                cm[camStr] || [];


            if (!models.length) {
                return;
            }


            log(
                idx,
                "Restarting detection after timeout"
            );


            await fetch(
                "/api/start",
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({
                        camera: idx,
                        models,
                        rtsp: meta.rtsp,
                        conf: 0.25,
                        iou: 0.45,
                        location:
                            meta.location ||
                            "Camera " +
                            (idx + 1)
                    })
                }
            );


            if (badge) {

                badge.className =
                    "mode-badge active";

                badge.textContent =
                    "● Starting AI model...";
            }


            showAiLoadingOverlay(
                box,
                idx
            );


            waitAndSwitch(
                video,
                meta,
                idx,
                box
            );

        } catch (err) {

            errorLog(
                idx,
                "Detection retry failed",
                err
            );
        }

    }, 5000);
}


/* ============================================================
   AI LOADING OVERLAY
   ============================================================ */

function showAiLoadingOverlay(box, idx) {

    removeAiLoadingOverlay(box);

    const wrap =
        box.querySelector(".video-wrap");

    if (!wrap) {
        return;
    }


    const overlay =
        document.createElement("div");

    overlay.className =
        "ai-loading-overlay";

    overlay.id =
        `ai-overlay-${idx}`;


    overlay.style.cssText = `
        position:absolute;
        inset:0;
        display:flex;
        align-items:center;
        justify-content:center;
        background:rgba(0,0,0,0.45);
        z-index:10;
        pointer-events:none;
    `;


    overlay.innerHTML = `
        <div style="
            display:flex;
            flex-direction:column;
            align-items:center;
            gap:10px;
            padding:18px 26px;
            background:rgba(0,18,36,0.90);
            border:1px solid rgba(0,229,160,0.45);
            border-radius:10px;
            font-family:monospace;
        ">

            <div style="
                width:26px;
                height:26px;
                border:3px solid rgba(0,229,160,0.2);
                border-top-color:#00e5a0;
                border-radius:50%;
                animation:_ai_spin 0.85s linear infinite;
            "></div>

            <div style="
                color:#00e5a0;
                font-size:0.74rem;
                font-weight:700;
                letter-spacing:0.05em;
            ">
                ● AI MODEL LOADING...
            </div>

            <div style="
                color:rgba(255,255,255,0.55);
                font-size:0.62rem;
                text-align:center;
                max-width:180px;
                line-height:1.4;
            ">
                RAW stream continues while detection starts.
            </div>

        </div>

        <style>
            @keyframes _ai_spin {
                to {
                    transform:rotate(360deg);
                }
            }
        </style>
    `;


    wrap.style.position = "relative";

    wrap.appendChild(overlay);
}


function removeAiLoadingOverlay(box) {

    const el =
        box.querySelector(
            ".ai-loading-overlay"
        );

    if (el) {
        el.remove();
    }
}


/* ============================================================
   WAIT FOR RAW STREAM
   ============================================================ */

async function waitForRawStream(
    meta,
    idx
) {

    const TIMEOUT_MS = 15000;

    const start = Date.now();


    while (
        Date.now() - start <
        TIMEOUT_MS
    ) {

        try {

            const playlist =
                await getPlaylist(
                    meta.hls_raw
                );


            if (
                playlist.segments.length >= 1
            ) {

                const latest =
                    playlist.segments[
                        playlist.segments.length - 1
                    ];


                const base =
                    meta.hls_raw.replace(
                        /\/[^/]+$/,
                        "/"
                    );


                const result =
                    await checkSegment(
                        base + latest
                    );


                if (
                    result.ok &&
                    result.size > 1000
                ) {

                    log(
                        idx,
                        "Fresh RAW stream ready",
                        latest,
                        result.size
                    );

                    return true;
                }
            }

        } catch (err) {

            warn(
                idx,
                "Waiting for RAW stream",
                err
            );
        }


        await sleep(500);
    }


    warn(
        idx,
        "RAW stream readiness timeout"
    );

    return false;
}


/* ============================================================
   UI
   ============================================================ */

function renderUI(
    box,
    i,
    meta,
    status,
    cameraModelsMap
) {

    const video =
        box.querySelector("video");

    const camStr =
        String(i);

    const badge =
        box.querySelector(
            ".mode-badge"
        );


    const assigned =
        cameraModelsMap[camStr] || [];


    const assignedText =
        assigned
            .map(
                m => m.replace(".pt", "")
            )
            .join(", ");


    const updateBadge =
        (isActive) => {

            if (!badge) {
                return;
            }


            badge.style.cssText = "";


            if (isActive) {

                badge.className =
                    "mode-badge active";

                badge.textContent =
                    assignedText
                        ? "● AI: " +
                          assignedText
                        : "● AI ACTIVE";

            } else {

                badge.className =
                    "mode-badge raw";

                badge.textContent =
                    "○ RAW";
            }
        };


    /* ========================================================
       RESTORE CURRENT STATE
       ======================================================== */

    if (
        status.active.includes(camStr)
    ) {

        box.classList.add(
            "detecting"
        );


        updateBadge(true);


        /*
         * Detection is already running.
         *
         * Direct detected URL.
         */
        playHLS(
            video,
            meta.hls_detected,
            i,
            {
                generation:
                    newGeneration(i),
                label: "DETECTED"
            }
        );

    } else {

        box.classList.remove(
            "detecting"
        );


        updateBadge(false);


        playHLS(
            video,
            meta.hls_raw,
            i,
            {
                generation:
                    newGeneration(i),
                label: "RAW"
            }
        );
    }


    /* ========================================================
       ASSIGNED MODELS
       ======================================================== */

    const chipsList =
        box.querySelector(
            ".assigned-chips-list"
        );


    if (chipsList) {

        chipsList.innerHTML = "";


        assigned.forEach(model => {

            const chip =
                document.createElement(
                    "span"
                );


            chip.className =
                "model-chip checked";


            chip.textContent =
                model.replace(".pt", "");


            chipsList.appendChild(
                chip
            );
        });
    }


    /* ========================================================
       SLIDERS
       ======================================================== */

    const confSlider =
        box.querySelector(
            ".conf-slider"
        );


    const iouSlider =
        box.querySelector(
            ".iou-slider"
        );


    if (confSlider) {

        confSlider.oninput =
            () => {

                const value =
                    parseFloat(
                        confSlider.value
                    );


                const valueElement =
                    box.querySelector(
                        ".conf-val"
                    );


                if (valueElement) {

                    valueElement.textContent =
                        value.toFixed(2);
                }
            };
    }


    if (iouSlider) {

        iouSlider.oninput =
            () => {

                const value =
                    parseFloat(
                        iouSlider.value
                    );


                const valueElement =
                    box.querySelector(
                        ".iou-val"
                    );


                if (valueElement) {

                    valueElement.textContent =
                        value.toFixed(2);
                }
            };
    }


    /* ========================================================
       START DETECTION
       ======================================================== */

    const startButton =
        box.querySelector(".start");


    if (startButton) {

        startButton.onclick =
            async () => {

                /*
                 * Prevent double clicks.
                 */
                if (
                    box.classList.contains(
                        "starting-detection"
                    )
                ) {
                    return;
                }


                box.classList.add(
                    "starting-detection"
                );


                try {

                    /*
                     * Get assigned models.
                     */
                    const cm =
                        await (
                            await fetch(
                                "/api/camera-models"
                            )
                        ).json();


                    const models =
                        cm[camStr] || [];


                    if (!models.length) {

                        alert(
                            "No models assigned to this camera.\n" +
                            "Go to Manage Cameras and assign a model."
                        );

                        return;
                    }


                    const conf =
                        confSlider
                            ? parseFloat(
                                confSlider.value
                            )
                            : 0.25;


                    const iou =
                        iouSlider
                            ? parseFloat(
                                iouSlider.value
                            )
                            : 0.45;


                    const location =
                        meta.location ||
                        meta.label ||
                        "Camera " +
                        (i + 1);


                    /*
                     * New generation.
                     */
                    const generation =
                        newGeneration(i);


                    /*
                     * Mark detection active.
                     *
                     * IMPORTANT:
                     *
                     * DO NOT destroy RAW HLS here.
                     *
                     * RAW remains visible.
                     */
                    box.classList.add(
                        "detecting"
                    );


                    updateBadge(true);


                    if (badge) {

                        badge.textContent =
                            "● Starting AI model...";
                    }


                    /*
                     * Tell backend to start YOLO.
                     */
                    const response =
                        await fetch(
                            "/api/start",
                            {
                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json"
                                },

                                body:
                                    JSON.stringify({
                                        camera: i,
                                        models,
                                        rtsp:
                                            meta.rtsp,
                                        conf,
                                        iou,
                                        location
                                    })
                            }
                        );


                    if (!response.ok) {

                        throw new Error(
                            `/api/start HTTP ${response.status}`
                        );
                    }


                    /*
                     * Show overlay.
                     *
                     * RAW video is still underneath.
                     */
                    showAiLoadingOverlay(
                        box,
                        i
                    );


                    /*
                     * Wait for real detected HLS.
                     */
                    waitAndSwitch(
                        video,
                        meta,
                        i,
                        box
                    );

                } catch (err) {

                    errorLog(
                        i,
                        "START failed",
                        err
                    );


                    box.classList.remove(
                        "detecting"
                    );


                    updateBadge(false);

                } finally {

                    box.classList.remove(
                        "starting-detection"
                    );
                }
            };
    }


    /* ========================================================
       STOP DETECTION
       ======================================================== */

    const stopButton =
        box.querySelector(".stop");


    if (stopButton) {

        stopButton.onclick =
            async () => {

                /*
                 * Invalidate all pending
                 * detection switching.
                 */
                newGeneration(i);


                removeAiLoadingOverlay(
                    box
                );


                box.classList.remove(
                    "detecting"
                );


                updateBadge(false);


                /*
                 * Destroy detected HLS.
                 */
                destroyHls(i);


                /*
                 * Reset MSE/video.
                 */
                resetVideo(video);


                try {

                    await fetch(
                        "/api/stop",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body:
                                JSON.stringify({
                                    camera: i
                                })
                        }
                    );

                } catch (err) {

                    warn(
                        i,
                        "/api/stop failed",
                        err
                    );
                }


                /*
                 * Wait until RAW HLS is actually
                 * producing fresh segments.
                 */
                const ready =
                    await waitForRawStream(
                        meta,
                        i
                    );


                /*
                 * Give filesystem/MSE a small
                 * cleanup window.
                 */
                await sleep(300);


                /*
                 * Start RAW.
                 */
                if (ready) {

                    playHLS(
                        video,
                        meta.hls_raw,
                        i,
                        {
                            generation:
                                switchGeneration[i],
                            label: "RAW"
                        }
                    );

                } else {

                    /*
                     * Even if readiness check timed
                     * out, let HLS.js retry RAW.
                     */
                    playHLS(
                        video,
                        meta.hls_raw,
                        i,
                        {
                            generation:
                                switchGeneration[i],
                            label: "RAW"
                        }
                    );
                }
            };
    }
}


/* ============================================================
   INIT
   ============================================================ */

let initRunning = false;
let initQueued = false;


async function init() {

    /*
     * Prevent two init() calls from creating
     * two HLS players for the same camera.
     */
    if (initRunning) {

        initQueued = true;

        return;
    }


    initRunning = true;


    try {

        const [
            streams,
            status,
            cameraModels
        ] = await Promise.all([

            fetch(
                "/api/streams"
            ).then(
                r => r.json()
            ),

            fetch(
                "/api/status"
            ).then(
                r => r.json()
            ),

            fetch(
                "/api/camera-models"
            ).then(
                r => r.json()
            )
        ]);


        const streamsById =
            new Map(
                streams.map(
                    stream => [
                        String(stream.id),
                        stream
                    ]
                )
            );


        const seen =
            new Set();


        document
            .querySelectorAll(".box")
            .forEach(box => {

                const camId =
                    box.dataset.cameraId;


                const meta =
                    streamsById.get(
                        String(camId)
                    );


                if (!meta) {

                    box.style.display =
                        "none";

                    return;
                }


                /*
                 * Avoid creating duplicate
                 * HLS players for duplicate
                 * DOM boxes.
                 */
                if (
                    seen.has(
                        String(camId)
                    )
                ) {
                    return;
                }


                seen.add(
                    String(camId)
                );


                renderUI(
                    box,
                    Number(camId),
                    meta,
                    status,
                    cameraModels
                );
            });


    } catch (err) {

        errorLog(
            "INIT",
            "init failed",
            err
        );

    } finally {

        initRunning = false;


        if (initQueued) {

            initQueued = false;

            setTimeout(
                init,
                0
            );
        }
    }
}


/* ============================================================
   EXPORT
   ============================================================ */

window.RtspDetection = {
    init
};


window.addEventListener(
    "load",
    init
);


window.addEventListener(
    "rtsp-dashboard-ready",
    init
);
